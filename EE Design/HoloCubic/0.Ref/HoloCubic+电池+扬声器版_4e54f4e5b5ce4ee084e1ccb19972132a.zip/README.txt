<p>大家好，我是洪磷<a href="https://space.bilibili.com/27718986" target="_blank">@Bilibili</a></p>
<p>是之前给甲方做完产品之后开源出来的，增加了电池管理功能，兼容AIO固件，可在其之上开发闹钟等应用。</p>
<p>配套视频会在2023.3与大家见面，视频重点在于制作好看的外壳，所涉及的技术难度不高。</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。